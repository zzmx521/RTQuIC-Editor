# RT-QuIC Editor v2.2 Windows 打包包

本文件夹是与原 macOS 版分开的 Windows x64 适配版源码，不会覆盖原程序和原始数据。

## 在 Windows 10/11 x64 上生成安装包

1. 安装 **Python 3.12 x64**，安装时保留 Python Launcher（`py`）。
2. 安装 **Inno Setup 6**（如果只需要免安装 ZIP，可跳过）。
3. 双击 `build_windows.bat`。
4. 结果位于 `release` 文件夹：
   - `RT-QuIC-Editor-v2.2-Windows-x64-Setup.exe`：Windows 安装程序。
   - `RT-QuIC-Editor-v2.2-Windows-x64-Portable.zip`：免安装版。

## Windows 适配内容

- 程序资源改为随安装包携带，不依赖 macOS 上的 `.claude` 路径。
- 数据和工作区保存到用户的 `Documents\RT-QuIC-Editor` 目录。
- 桌面输出自动适配 Windows 的桌面路径（包括 OneDrive 重定向）。
- “在文件夹中显示”、打开 HTML 报告和视图已改为 Windows Explorer 兼容实现。
- 保留 Excel/CSV/TSV/JSON 导入、动力学指标、交互曲线、批量报告、PDF/TIFF 导出和 Prism 数据导出等功能。

## 建议测试

安装后先用一份已知的 RT-QuIC 数据验证：导入、复孔分组、指标计算、视图生成、PDF/TIFF 和 Prism CSV 导出。当前构建未做代码签名，Windows 可能显示 SmartScreen 提示。

