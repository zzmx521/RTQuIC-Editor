@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo [1/5] Locating Python 3.12...
py -3.12 --version >nul 2>&1
if errorlevel 1 (
  echo Python 3.12 x64 was not found.
  echo Install it from https://www.python.org/downloads/windows/ and enable the Python Launcher.
  pause
  exit /b 1
)

echo [2/5] Creating the isolated build environment...
if not exist ".venv-build\Scripts\python.exe" py -3.12 -m venv .venv-build
call ".venv-build\Scripts\activate.bat"
python -m pip install --upgrade pip
if errorlevel 1 goto :failed
python -m pip install -r requirements-windows.txt
if errorlevel 1 goto :failed

echo [3/5] Building the Windows application...
python -m PyInstaller --noconfirm --clean RT-QuIC-Editor-Windows.spec
if errorlevel 1 goto :failed

echo [4/5] Creating the portable ZIP...
if not exist release mkdir release
if exist "release\RT-QuIC-Editor-v2.2-Windows-x64-Portable.zip" del /q "release\RT-QuIC-Editor-v2.2-Windows-x64-Portable.zip"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path 'dist\RT-QuIC-Editor\*' -DestinationPath 'release\RT-QuIC-Editor-v2.2-Windows-x64-Portable.zip' -CompressionLevel Optimal"
if errorlevel 1 goto :failed

echo [5/5] Creating the installer when Inno Setup is available...
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ISCC%" (
  "%ISCC%" installer.iss
  if errorlevel 1 goto :failed
  echo Installer created successfully.
) else (
  echo Inno Setup 6 was not found. The portable ZIP is ready.
  echo To create Setup.exe, install Inno Setup 6 and run this file again.
)

echo.
echo Build complete. Output files are in:
echo %CD%\release
explorer "%CD%\release"
exit /b 0

:failed
echo.
echo Build failed. Review the messages above.
pause
exit /b 1

